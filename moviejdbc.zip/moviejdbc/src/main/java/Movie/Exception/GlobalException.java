package Movie.Exception;

public class GlobalException extends Exception
{

		public GlobalException(String s) {
			super(s);
			}

}
