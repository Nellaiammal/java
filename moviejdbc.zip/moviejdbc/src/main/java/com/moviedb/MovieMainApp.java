package com.moviedb;

import java.sql.SQLException;
import java.util.Scanner;

public class MovieMainApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Menu
		int ch=0;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("************Movie Management System Menu************");
			System.out.println("1. Adding a Movie in the Library");
			System.out.println("2. Updating a Movie in the Library");
			System.out.println("3. Deleting a Movie from the Library");
			System.out.println("4. Searching a Movie in the Library");
			System.out.println("5. Assign movie to a category");
			System.out.println("6. View All movies");
			System.out.println("0. Exit the application");
			ch=sc.nextInt();sc.nextLine();
			
			
			switch(ch)
			{
			case 1: System.out.println("Add");
					MovieOperation.addMovie();
					break;

			case 2: 
				MovieOperation.updateMovie();
							break;

			case 3: System.out.println("Delete");
					MovieOperation.DeleteMovie();
					break;

			case 4: MovieOperation.searchMovie();
					break;

			case 5: 
					MovieOperation.assigneeMovie();
					
					break;
			case 6: MovieOperation.viewAllMovies();
					break;
			case 0: System.out.println("Exit");
					break;
			
			default: System.out.println("Please try again");

			}

		}
		while(ch!=0);

	}	
}
