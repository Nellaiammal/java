package com.moviedb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class MovieOperation {

	
	private static Connection conn;
	private static Statement st;
	private static ResultSet rs;
	private static int accno;
	static {
			try {
				conn=MovieConnection.getDatabaseConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 

	static Scanner sc=new Scanner(System.in);
	

	public static void addMovie() throws SQLException {
		
		st=conn.createStatement();
		System.out.println("Enter the movie id : ");
		int mid=sc.nextInt();sc.nextLine();
		 System.out.println("enter movie name");
		 String mname=sc.nextLine();
		 System.out.println("enter movie text");
		 String mtext=sc.nextLine();
		 System.out.println("enter movie category");
		 String cat=sc.nextLine();
		 System.out.println("enter movie release date");
		 String mdate=sc.nextLine();
		 System.out.println("enter movie assigned to");
		 String massignedTo=sc.nextLine();
		 
		 String s1="Insert into movie values("+mid+",'"+mname+"','"+mtext+"','"+cat+"','"+mdate+"','"+massignedTo+"')";
		 
		 int res=st.executeUpdate(s1);
			if(res>0) {
				System.out.println("Inserted Successfully....!!!!!");
			}
		
	}

	public static void viewAllMovies() throws SQLException  {
		st=conn.createStatement();
		String s1="select * from Movie";
		rs=st.executeQuery(s1);
		System.out.println("Movie Id \t Movie Name \t Movie Text \t Movie Category \t M Date \t movie Assigned To");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"\t \t "+rs.getString(2)+"\t \t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t \t"+rs.getString(5)+"\t \t"+rs.getString(6));
		}
		
		
	}

	public static void assigneeMovie() throws SQLException {
		st=conn.createStatement();
		System.out.println("Enter the movie name to be be assigned to a user: ");
		String mname= sc.nextLine();
		System.out.println("Enter the name of the assignee user: ");
		String as=sc.nextLine();
		String s1="update movie set massignedTo='"+as+"' where mname='"+mname+"'";
		
		
		int res=st.executeUpdate(s1);
		if(res>0) {//how many records are updated
			System.out.println("Assigned Successfully....!");
		}
		
		
		
	}

	public static void searchMovie() throws SQLException {
		
		System.out.println("enter a movie name");
		String name=sc.nextLine();
		
		st=conn.createStatement();
		String s1="select * from Movie where mname='"+name+"'";
		
		
		 rs=st.executeQuery(s1);
		
		System.out.println("Movie Id \t Movie Name \t Movie Text \t Movie Category \t M Date \t movie Assigned To");
		if(rs.next())
		{
			System.out.println(rs.getInt("mid")+"\t  "+rs.getString("mname")+" \t"+rs.getString("mtext")+"\t"+rs.getString("mcategory")+" \t"+rs.getString("mcdate")+" \t"+rs.getString("massignedTo"));
		}
		
	}

	public static void DeleteMovie() throws SQLException {
		
		st=conn.createStatement();
		System.out.println("Enter the movie name to delete: ");
		String mname= sc.nextLine();
		String s1="delete from movie where mname='"+mname+"'";
		int res=st.executeUpdate(s1);
		if(res>0) {//how many records are updated
			System.out.println("deleted  Successfully....!");
		}
		
		
	}

	public static void updateMovie() throws SQLException {
		
		
		st=conn.createStatement();
		System.out.println("Enter the movie name : ");
		String name= sc.nextLine();
		System.out.println("Enter the new movie name : ");
		String as=sc.nextLine();
		String s1="update movie set mname='"+as+"' where mname='"+name+"'";
		
		
		int res=st.executeUpdate(s1);
		if(res>0) {//how many records are updated
			System.out.println("updated Successfully....!");
		}
		
		
		
	}

	
}

